param(
    [string]$PortName = 'COM14',
    [ValidateRange(10, 30)]
    [int]$RunTimeoutSeconds = 16
)

$ErrorActionPreference = 'Stop'
$logDir = Join-Path $PSScriptRoot 'logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$logPath = Join-Path $logDir ('post_exit_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.csv')
$port = [System.IO.Ports.SerialPort]::new(
    $PortName, 115200, [System.IO.Ports.Parity]::None, 8,
    [System.IO.Ports.StopBits]::One
)
$port.ReadTimeout = 300
$port.NewLine = "`n"
$writer = $null
$started = $false
$cornerSeen = $false
$stopLine = ''

try {
    $port.Open()
    $port.DiscardInBuffer()
    $writer = [System.IO.StreamWriter]::new(
        $logPath, $false, [System.Text.Encoding]::UTF8
    )
    $writer.AutoFlush = $true
    $writer.WriteLine('pc_time,uart_line')

    $deadline = (Get-Date).AddSeconds(4)
    $safeReports = 0
    while ((Get-Date) -lt $deadline -and $safeReports -lt 3) {
        try { $line = $port.ReadLine().Trim() }
        catch [System.TimeoutException] { continue }
        if (!$line) { continue }
        $writer.WriteLine('"' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') +
                          '","' + $line.Replace('"', '""') + '"')
        if (!$line.StartsWith('D,')) { continue }
        $fields = $line.Split(',')
        if ($fields.Length -lt 19) { throw "Invalid status: $line" }
        $bits = [Convert]::ToInt32($fields[3], 16)
        $lit = 0
        for ($i = 0; $i -lt 8; $i++) { if ($bits -band (1 -shl $i)) { $lit++ } }
        if ([int]$fields[2] -ne 0 -or
            ($bits -band 0x18) -eq 0 -or $lit -gt 2 -or
            [int]$fields[4] -gt 200 -or
            [int]$fields[10] -ne 0 -or [int]$fields[11] -ne 0 -or
            [int]$fields[17] -gt 300 -or [int]$fields[18] -eq 0) {
            throw "Post-exit preflight failed: $line"
        }
        $safeReports++
    }
    if ($safeReports -lt 3) { throw 'No three fresh stopped reports.' }
    Write-Output "POST_EXIT_READY,$PortName,$logPath,line_visible,motors_stopped"

    $port.Write('G')
    Write-Output 'POST_EXIT_START_COMMAND_SENT,G'
    $deadline = (Get-Date).AddSeconds($RunTimeoutSeconds)
    while ((Get-Date) -lt $deadline -and !$stopLine) {
        try { $line = $port.ReadLine().Trim() }
        catch [System.TimeoutException] { continue }
        if (!$line) { continue }
        $writer.WriteLine('"' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') +
                          '","' + $line.Replace('"', '""') + '"')
        if ($line.StartsWith('EVENT,START,')) {
            $started = $true
            Write-Output $line
        } elseif ($line -eq 'EVENT,CORNER_RIGHT') {
            $cornerSeen = $true
            Write-Output $line
        } elseif ($line.StartsWith('EVENT,STOP,')) {
            $stopLine = $line
            Write-Output $line
        } elseif ($line.StartsWith('EVENT,REFUSE_START,')) {
            throw "Start refused: $line"
        }
    }
    if (!$stopLine) {
        $port.Write('X')
        throw 'Post-exit timeout; X stop sent. Cut motor power if needed.'
    }
} finally {
    if ($null -ne $writer) { $writer.Dispose() }
    if ($port.IsOpen) { $port.Close() }
    $port.Dispose()
}

Write-Output "LOG_PATH,$logPath"
if (!$started -or !$cornerSeen -or
    $stopLine -notlike '*ONE_CORNER_COMPLETE,turns=1*') {
    throw "Post-exit corner completion was not confirmed: $stopLine"
}
Write-Output 'POST_EXIT_CORNER_CONFIRMED'
