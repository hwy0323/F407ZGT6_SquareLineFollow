param(
    [string]$PortName = 'COM14',
    [switch]$DryRun,
    [switch]$ResumeAtParkingLine
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$cornerRoot = Join-Path $projectRoot 'F407ZGT6_OneCorner_To_ParkingStart'
$followRoot = Join-Path $projectRoot 'F407ZGT6_PostExit_SlowAlign_2026-10-07'
$cornerBin = Join-Path $cornerRoot 'build\F407ZGT6_OneCorner_To_ParkingStart.bin'
$routeBin = Join-Path $PSScriptRoot 'build\F407ZGT6_FullParking_F200_Handoff_2026-10-07.bin'
$followBin = Join-Path $followRoot 'build\F407ZGT6_PostExit_SlowAlign_2026-10-07.bin'
$openocd = 'F:\cbide\STM32CubeIDE_1.19.0\STM32CubeIDE\plugins\com.st.stm32cube.ide.mcu.externaltools.openocd.win32_2.4.200.202505051030\tools\bin\openocd.exe'
$openocdScripts = 'F:\cbide\STM32CubeIDE_1.19.0\STM32CubeIDE\plugins\com.st.stm32cube.ide.mcu.debug.openocd_2.3.100.202501240831\resources\openocd\st_scripts'
$expected = @(
    @{Path=$cornerBin; Hash='4DCBF3C356FA32DE016B3A3321502B4F9A21F1ED57DB361F2CFCB5972CEED27C'},
    @{Path=$routeBin; Hash='DDBCA608E1CBE7A06B5E7D087F9816E7487E2FFEADADAF642A1767B5106323E2'},
    @{Path=$followBin; Hash='1E4AEC335DBBB6C0BC09ABD6D06DE51885439CD9100A29A985A91BFD14827C8F'}
)

foreach ($item in $expected) {
    if (!(Test-Path -LiteralPath $item.Path)) { throw "Missing binary: $($item.Path)" }
    $hash = (Get-FileHash -LiteralPath $item.Path -Algorithm SHA256).Hash
    if ($hash -ne $item.Hash) { throw "Binary changed: $($item.Path), $hash" }
}
if (!(Test-Path -LiteralPath $openocd)) { throw "Missing OpenOCD: $openocd" }
if ($DryRun) {
    'PLAN,one_true_corner,parking_line_stop'
    'PLAN,F209,L090,B200,forward_until_gray_FF_max_200mm'
    'PLAN,F100,R050,F180,R060,F200,no_fixed_final_turn,step_pause_200ms'
    'PLAN,slow_follow_only_if_centered,one_corner_then_align_center_and_stop'
    return
}

function Flash-Binary([string]$Path) {
    $slash = $Path.Replace('\', '/')
    $cmd = "program $slash verify reset exit 0x08000000"
    $openArgs = @('-s', $openocdScripts, '-f', 'interface/cmsis-dap.cfg',
                  '-c', 'adapter serial d6db18e7', '-c', 'adapter speed 100',
                  '-f', 'target/stm32f4x.cfg', '-c', $cmd)
    $lines = & $openocd @openArgs 2>&1
    if ($LASTEXITCODE -ne 0 -or ($lines | Out-String) -notmatch '\*\* Verified OK \*\*') {
        throw "Flash failed: $Path`n$($lines | Out-String)"
    }
    "FLASH_VERIFIED,$Path"
}

function Send-Stop {
    $port = $null
    try {
        $port = [System.IO.Ports.SerialPort]::new(
            $PortName, 115200, [System.IO.Ports.Parity]::None, 8,
            [System.IO.Ports.StopBits]::One)
        $port.Open()
        $port.Write('X')
        'EMERGENCY_X_SENT'
    } catch {
        "EMERGENCY_X_UNAVAILABLE,$($_.Exception.Message)"
    } finally {
        if ($null -ne $port) {
            if ($port.IsOpen) { $port.Close() }
            $port.Dispose()
        }
    }
}

function Run-Route {
    $logDir = Join-Path $PSScriptRoot 'logs'
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    $logPath = Join-Path $logDir ('full_parking_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.csv')
    $port = [System.IO.Ports.SerialPort]::new(
        $PortName, 115200, [System.IO.Ports.Parity]::None, 8,
        [System.IO.Ports.StopBits]::One)
    $port.ReadTimeout = 300
    $port.NewLine = "`n"
    $writer = $null
    $stepEnds = 0
    $gateSeen = $false
    $routeDone = $false
    try {
        $port.Open()
        $port.DiscardInBuffer()
        $writer = [System.IO.StreamWriter]::new($logPath, $false, [System.Text.Encoding]::UTF8)
        $writer.AutoFlush = $true
        $writer.WriteLine('pc_time,uart_line')
        $preflightDeadline = (Get-Date).AddSeconds(5)
        $idleReports = 0
        $grayFresh = $false
        while ((Get-Date) -lt $preflightDeadline -and ($idleReports -lt 3 -or !$grayFresh)) {
            try { $line = $port.ReadLine().Trim() }
            catch [System.TimeoutException] { continue }
            if (!$line) { continue }
            $writer.WriteLine('"' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') +
                              '","' + $line.Replace('"', '""') + '"')
            if ($line.StartsWith('S,')) {
                $f = $line.Split(',')
                if ($f.Length -ge 18 -and $f[16] -match '^\d+$' -and
                    $f[17] -match '^\d+$' -and $f[2] -eq '0' -and
                    $f[10] -eq '0' -and $f[11] -eq '0' -and
                    [int]$f[16] -lt 150 -and [int]$f[17] -gt 0) {
                    $idleReports++
                }
            } elseif ($line.StartsWith('B3,')) {
                $f = $line.Split(',')
                if ($f.Length -ge 4 -and $f[3] -match '^\d+$' -and
                    [int]$f[3] -lt 100) { $grayFresh = $true }
            }
        }
        if ($idleReports -lt 3 -or !$grayFresh) { throw 'No fresh stopped motor, IMU and gray reports.' }
        'ROUTE_PREFLIGHT_OK,motors_stopped,imu_fresh,gray_fresh'
        $port.Write("G`n")
        'ROUTE_START_COMMAND_SENT,G'
        $deadline = (Get-Date).AddSeconds(50)
        while ((Get-Date) -lt $deadline -and !$routeDone) {
            try { $line = $port.ReadLine().Trim() }
            catch [System.TimeoutException] { continue }
            if (!$line) { continue }
            $writer.WriteLine('"' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') +
                              '","' + $line.Replace('"', '""') + '"')
            if ($line.StartsWith('EVENT,STEP_END,')) {
                $stepEnds++
                $line
            } elseif ($line.StartsWith('EVENT,GATE_CONFIRMED,')) {
                $gateSeen = $true
                $line
            } elseif ($line.StartsWith('EVENT,ROUTE_START,') -or
                      $line.StartsWith('EVENT,ROUTE_STEP,') -or
                      $line.StartsWith('EVENT,ROUTE_DONE,')) {
                $line
                if ($line.StartsWith('EVENT,ROUTE_DONE,')) { $routeDone = $true }
            } elseif ($line.StartsWith('EVENT,ROUTE_ABORT,') -or
                      $line.StartsWith('EVENT,REFUSE,')) {
                throw "Route stopped: $line"
            }
        }
        if (!$routeDone -or !$gateSeen -or $stepEnds -ne 9) {
            $port.Write('X')
            throw "Route incomplete: done=$routeDone, gate=$gateSeen, steps=$stepEnds"
        }
        'FULL_PARKING_ROUTE_CONFIRMED'
        "LOG_PATH,$logPath"
    } finally {
        if ($null -ne $writer) { $writer.Dispose() }
        if ($port.IsOpen) { $port.Close() }
        $port.Dispose()
    }
}

try {
    if (!$ResumeAtParkingLine) {
        Flash-Binary $cornerBin
        $corner = & (Join-Path $cornerRoot 'capture_parking_start.ps1') -PortName $PortName -RunTimeoutSeconds 18
        $corner | ForEach-Object { $_ }
        if ($corner -notcontains 'PARKING_START_CONFIRMED') { throw 'Parking-line stop not confirmed.' }
        $parking = $corner | Where-Object { $_ -like 'EVENT,PARKING_START,*' } | Select-Object -Last 1
        if (!$parking) { throw 'No parking-line event.' }
        $f = $parking.Split(',')
        $fromCorner = [int]($f[-1] -replace '^from_corner=', '')
        if ($f[3].ToUpperInvariant() -notin @('0F','1F','74') -or
            $fromCorner -lt 1200 -or $fromCorner -gt 2000) {
            throw "Parking line differs from recorded start: $parking"
        }
    } else {
        'RESUME_AT_USER_CONFIRMED_PARKING_LINE'
    }
    Flash-Binary $routeBin
    Run-Route
    Flash-Binary $followBin
    $follow = & (Join-Path $followRoot 'capture_post_exit.ps1') -PortName $PortName -RunTimeoutSeconds 16
    $follow | ForEach-Object { $_ }
    if ($follow -notcontains 'POST_EXIT_CORNER_CONFIRMED') {
        throw 'Post-exit right corner not confirmed.'
    }
    'FULL_PARKING_AND_NEXT_CORNER_CONFIRMED_BY_SERIAL'
} catch {
    "FULL_PARKING_ABORT,$($_.Exception.Message)"
    Send-Stop
    throw
}
