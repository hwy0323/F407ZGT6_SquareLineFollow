#ifndef ROUTE_DATA_H
#define ROUTE_DATA_H

typedef struct {
  char direction;
  unsigned short value;
  unsigned char source_step;
} RouteStep;

/* From the confirmed parking-line stop: park, find the all-black line,
 * then replay the Basic-3 exit and stop. F/B/G values are millimetres;
 * L/R values are degrees. G is capped at 200 mm, not a fixed move.
 */
static const RouteStep route_steps[] = {
  {'F', 209U, 1U},
  {'L', 90U, 2U},
  {'B', 200U, 3U},
  {'G', 200U, 4U},
  {'F', 100U, 5U},
  {'R', 50U, 6U},
  {'F', 180U, 7U},
  {'R', 60U, 8U},
  {'F', 200U, 9U}
};

#define ROUTE_STEP_COUNT (sizeof(route_steps) / sizeof(route_steps[0]))

#endif
