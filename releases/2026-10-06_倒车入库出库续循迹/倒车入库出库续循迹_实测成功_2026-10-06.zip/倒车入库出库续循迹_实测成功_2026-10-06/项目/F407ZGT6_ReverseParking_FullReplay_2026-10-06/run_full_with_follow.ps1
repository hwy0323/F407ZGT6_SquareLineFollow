param(
    [string]$PortName = 'COM14',
    [switch]$DryRun,
    [switch]$ResumeFromP1
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$cornerRoot = Join-Path $projectRoot 'F407ZGT6_OneCorner_To_ParkingStart'
$stepRoot = Join-Path $projectRoot 'F407ZGT6_ReverseParking_500ms'
$followRoot = Join-Path $projectRoot 'F407ZGT6_PostExit_OneCorner_Follow'
$cornerBin = Join-Path $cornerRoot 'build\F407ZGT6_OneCorner_To_ParkingStart.bin'
$stepBin = Join-Path $stepRoot 'build\F407ZGT6_ReverseParking_500ms.bin'
$followBin = Join-Path $followRoot 'build\F407ZGT6_PostExit_OneCorner_Follow.bin'
$openocd = 'F:\cbide\STM32CubeIDE_1.19.0\STM32CubeIDE\plugins\com.st.stm32cube.ide.mcu.externaltools.openocd.win32_2.4.200.202505051030\tools\bin\openocd.exe'
$openocdScripts = 'F:\cbide\STM32CubeIDE_1.19.0\STM32CubeIDE\plugins\com.st.stm32cube.ide.mcu.debug.openocd_2.3.100.202501240831\resources\openocd\st_scripts'
$cornerHash = '4DCBF3C356FA32DE016B3A3321502B4F9A21F1ED57DB361F2CFCB5972CEED27C'
$stepHash = '85A6F0933CCD258FF36D0B3D19C26CC2BE8DB91B58077CA37F607A39484EC12F'
$followHash = '2324B2AF3BF586F0206564D85462CECFDFF2160612D87A2CABA303D18D3FFFAD'

# The three forward trims and one backward trim landed at P1: 1238 counts.
# A single F209 is predicted to land there after the measured forward coasting.
$route = @(
    @{ Name = 'P1_merged_approach'; Command = 'F209'; Direction = 'F'; Target = 209; Expected = 1238; Tolerance = 80 },
    @{ Name = 'turn_into_bay';   Command = 'L090'; Direction = 'L'; Target = 9000; Expected = 9080; Tolerance = 350 },
    @{ Name = 'reverse_into_bay'; Command = 'B200'; Direction = 'B'; Target = 200; Expected = 1161; Tolerance = 80 },
    @{ Name = 'leave_bay';       Command = 'F200'; Direction = 'F'; Target = 200; Expected = 1189; Tolerance = 80 },
    @{ Name = 'turn_to_track';   Command = 'R090'; Direction = 'R'; Target = 9000; Expected = 9148; Tolerance = 350 },
    @{ Name = 'final_forward';   Command = 'F100'; Direction = 'F'; Target = 100; Expected = 617; Tolerance = 80 }
)

function Assert-Binary([string]$Path, [string]$ExpectedHash) {
    if (!(Test-Path -LiteralPath $Path)) { throw "Missing binary: $Path" }
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    if ($actual -ne $ExpectedHash) { throw "Unexpected binary hash: $Path $actual" }
}

function Flash-Binary([string]$Path) {
    $slashPath = $Path.Replace('\', '/')
    $command = "program $slashPath verify reset exit 0x08000000"
    $lines = & $openocd -s $openocdScripts -f 'interface/cmsis-dap.cfg' -f 'target/stm32f4x.cfg' -c $command 2>&1
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0 -or !(($lines | Out-String) -match '\*\* Verified OK \*\*')) {
        throw "Flash/verify failed for $Path. Output: $($lines | Out-String)"
    }
    Write-Output "FLASH_VERIFIED,$Path"
}

function Send-EmergencyStop {
    $port = $null
    try {
        $port = [System.IO.Ports.SerialPort]::new(
            $PortName, 115200, [System.IO.Ports.Parity]::None, 8,
            [System.IO.Ports.StopBits]::One
        )
        $port.Open()
        $port.Write('X')
        Write-Output 'EMERGENCY_X_SENT'
    } catch {
        Write-Output "EMERGENCY_X_UNAVAILABLE,$($_.Exception.Message)"
    } finally {
        if ($null -ne $port) {
            if ($port.IsOpen) { $port.Close() }
            $port.Dispose()
        }
    }
}

Assert-Binary $cornerBin $cornerHash
Assert-Binary $stepBin $stepHash
Assert-Binary $followBin $followHash
if (!(Test-Path -LiteralPath $openocd)) { throw "Missing OpenOCD: $openocd" }
if ($DryRun) {
    Write-Output "DRY_RUN,corner=$cornerBin,step=$stepBin,follow=$followBin,port=$PortName,resume=$ResumeFromP1"
    $dryRoute = if ($ResumeFromP1) { $route | Select-Object -Skip 1 } else { $route }
    foreach ($item in $dryRoute) {
        Write-Output "PLAN,$($item.Name),$($item.Command),expected=$($item.Expected),tolerance=$($item.Tolerance)"
    }
    Write-Output 'PLAN,flash_post_exit_follower,follow_and_stop_after_one_true_right_corner'
    return
}

try {
    if (!$ResumeFromP1) {
        Flash-Binary $cornerBin
        $cornerLines = & (Join-Path $cornerRoot 'capture_parking_start.ps1') -PortName $PortName -RunTimeoutSeconds 18
        $cornerLines | ForEach-Object { Write-Output $_ }
        if ($cornerLines -notcontains 'PARKING_START_CONFIRMED') {
            throw 'Corner-to-parking run was not confirmed.'
        }
        $parkingLine = $cornerLines | Where-Object { $_ -like 'EVENT,PARKING_START,*' } | Select-Object -Last 1
        if (!$parkingLine) { throw 'No parking-start event.' }
        $parking = $parkingLine.Split(',')
        $pattern = $parking[3].ToUpperInvariant()
        $cornerYaw = [int]$parking[4]
        $fromCorner = [int]($parking[-1] -replace '^from_corner=', '')
        if (@('0F', '1F') -notcontains $pattern -or
            $fromCorner -lt 1500 -or $fromCorner -gt 2000) {
            throw "Parking-line signature differs from repeated successful starts: $parkingLine"
        }
        Write-Output "PARKING_SIGNATURE_OK,$pattern,from_corner=$fromCorner,yaw=$cornerYaw"
        Flash-Binary $stepBin
    }
    $idleLines = & (Join-Path $stepRoot 'preflight.ps1') -PortName $PortName
    $idleLines | ForEach-Object { Write-Output $_ }
    if ($idleLines -notcontains 'PREFLIGHT_OK_NO_MOTION_COMMAND_SENT') {
        throw 'Step-controller preflight failed.'
    }
    $idleLine = $idleLines | Where-Object { $_ -like 'S,*' } | Select-Object -Last 1
    $idleFields = $idleLine.Split(',')
    $idleYaw = [int]$idleFields[8]
    if ($ResumeFromP1) {
        if ($idleFields[3] -ne '1' -or $idleFields[4] -ne 'F' -or
            $idleFields[5] -ne '209' -or $idleYaw -lt 9800 -or $idleYaw -gt 11000) {
            throw "Board is not at the recorded P1 state: $idleLine"
        }
        $recentCounts = @([Math]::Abs([int]$idleFields[12]),
                          [Math]::Abs([int]$idleFields[13]),
                          [Math]::Abs([int]$idleFields[14])) | Sort-Object
        if ($recentCounts[1] -lt 1160 -or $recentCounts[1] -gt 1320) {
            throw "P1 encoder range does not match: $idleLine"
        }
        $index = 1
        $stepsToRun = $route | Select-Object -Skip 1
        Write-Output "RESUME_P1_VERIFIED,yaw=$idleYaw,counts=$($recentCounts[1])"
    } else {
        $yawDifference = [Math]::Abs($idleYaw - $cornerYaw)
        if ($yawDifference -gt 18000) { $yawDifference = 36000 - $yawDifference }
        if ($yawDifference -gt 500) {
            throw "Yaw changed more than 5 degrees during firmware switch: $cornerYaw to $idleYaw"
        }
        $index = 0
        $stepsToRun = $route
    }

    foreach ($item in $stepsToRun) {
        $index++
        $lines = & (Join-Path $stepRoot 'record_step.ps1') -Command $item.Command -PortName $PortName
        $lines | ForEach-Object { Write-Output $_ }
        $endLine = $lines | Where-Object { $_ -like 'EVENT,STEP_END,*' } | Select-Object -Last 1
        if (!$endLine -or $lines -notcontains 'STEP_END_SEEN,True') {
            throw "Missing end event at step $index ($($item.Command))."
        }
        $finalIdle = $lines | Where-Object { $_ -like 'FINAL_IDLE,S,*' } | Select-Object -Last 1
        if (!$finalIdle) { throw "No final stopped report at step $index." }
        $idleFields = ($finalIdle -replace '^FINAL_IDLE,', '').Split(',')
        if ($idleFields.Length -lt 18 -or $idleFields[2] -ne '0' -or
            $idleFields[10] -ne '0' -or $idleFields[11] -ne '0') {
            throw "Motors not confirmed stopped at step $index`: $finalIdle"
        }
        $fields = $endLine.Split(',')
        $reason = $fields[3]
        $actualDirection = $fields[4]
        $target = [int]$fields[5]
        $progress = [int]$fields[10]
        if ([int]$fields[2] -ne $index -or
            $actualDirection -ne $item.Direction -or $target -ne $item.Target -or
            @('DONE', 'DISTANCE_OVERSHOOT', 'OVERSHOOT') -notcontains $reason -or
            [Math]::Abs($progress - $item.Expected) -gt $item.Tolerance) {
            throw "Unexpected step result; route aborted at $index`: $endLine"
        }
        Write-Output "STEP_ACCEPTED,$index,$($item.Name),$reason,progress=$progress"
        if ($index -eq 3) { Write-Output 'P2_PARKED_RECORDED' }
        if ($index -lt $route.Count) { Start-Sleep -Milliseconds 500 }
    }
    Write-Output 'PARKING_EXIT_SERIAL_CHECKS_PASSED'
    Flash-Binary $followBin
    $followLines = & (Join-Path $followRoot 'capture_post_exit.ps1') -PortName $PortName -RunTimeoutSeconds 16
    $followLines | ForEach-Object { Write-Output $_ }
    if ($followLines -notcontains 'POST_EXIT_CORNER_CONFIRMED') {
        throw 'Post-exit corner was not confirmed.'
    }
    Write-Output 'FULL_REPLAY_AND_NEXT_CORNER_SERIAL_CHECKS_PASSED_PHYSICAL_RESULT_NEEDS_USER_CONFIRMATION'
} catch {
    Write-Output "FULL_REPLAY_ABORT,$($_.Exception.Message)"
    Send-EmergencyStop
    throw
}
