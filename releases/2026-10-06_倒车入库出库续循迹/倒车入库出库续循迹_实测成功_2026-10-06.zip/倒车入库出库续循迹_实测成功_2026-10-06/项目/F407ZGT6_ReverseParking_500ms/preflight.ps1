param([string]$PortName = 'COM14')

$ErrorActionPreference = 'Stop'
$port = [System.IO.Ports.SerialPort]::new(
    $PortName, 115200, [System.IO.Ports.Parity]::None, 8,
    [System.IO.Ports.StopBits]::One
)
$port.NewLine = "`n"
$port.ReadTimeout = 300
try {
    $port.Open()
    $port.DiscardInBuffer()
    $port.Write("Q`n")
    $ack = $false
    $idle = 0
    $deadline = (Get-Date).AddSeconds(6)
    while ((Get-Date) -lt $deadline -and (!$ack -or $idle -lt 4)) {
        try { $line = $port.ReadLine().Trim() }
        catch [System.TimeoutException] { continue }
        if ($line.StartsWith('READY,')) { Write-Output $line }
        if ($line.StartsWith('ACK,Q')) {
            $ack = $true
            Write-Output $line
        }
        if (!$line.StartsWith('S,')) { continue }
        $fields = $line.Split(',')
        if ($fields.Length -lt 18 -or $fields[2] -ne '0' -or
            $fields[10] -ne '0' -or $fields[11] -ne '0' -or
            [int]$fields[16] -ge 150 -or [int]$fields[17] -eq 0) {
            throw "Idle or IMU check failed: $line"
        }
        $idle++
        Write-Output $line
    }
    if (!$ack -or $idle -lt 4) { throw 'UART or idle preflight timed out.' }
    Write-Output 'PREFLIGHT_OK_NO_MOTION_COMMAND_SENT'
} finally {
    if ($port.IsOpen) { $port.Close() }
    $port.Dispose()
}
