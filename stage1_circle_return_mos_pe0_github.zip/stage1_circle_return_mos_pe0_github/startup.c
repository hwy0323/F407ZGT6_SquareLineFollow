#include <stdint.h>
#include "stm32f407xx.h"

extern int main(void);
extern void __main(void);
extern void SysTick_Handler(void);
extern void HardFault_Handler(void);
extern void MemManage_Handler(void);
extern void BusFault_Handler(void);
extern void UsageFault_Handler(void);
extern void Default_Handler(void);

#define STACK_TOP_ADDRESS 0x20020000U

void Reset_Handler(void)
{
  /* Enable the Cortex-M4 floating-point unit before C library math runs. */
  SCB->CPACR |= (0xFU << 20);
  __DSB();
  __ISB();
  __main();
  for (;;) { }
}

__attribute__((used, aligned(256), section("RESET")))
const uintptr_t vector_table[98] = {
  [0] = STACK_TOP_ADDRESS,
  [1] = (uintptr_t)Reset_Handler,
  [2] = (uintptr_t)Default_Handler,
  [3] = (uintptr_t)HardFault_Handler,
  [4] = (uintptr_t)MemManage_Handler,
  [5] = (uintptr_t)BusFault_Handler,
  [6] = (uintptr_t)UsageFault_Handler,
  [7 ... 14] = (uintptr_t)Default_Handler,
  [15] = (uintptr_t)SysTick_Handler,
  [16 ... 97] = (uintptr_t)Default_Handler
};
