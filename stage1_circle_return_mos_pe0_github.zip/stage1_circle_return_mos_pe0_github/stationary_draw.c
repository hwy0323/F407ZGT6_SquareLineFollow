#include <math.h>
#include <stdint.h>
#include "stm32f407xx.h"

#define GPIO_PIN_0  (1U << 0)
#define GPIO_PIN_2  (1U << 2)
#define GPIO_PIN_3  (1U << 3)
#define GPIO_PIN_13 (1U << 13)
#define GPIO_PIN_15 (1U << 15)

/* Stage 1: fixed car, vertical paper. All distances below are millimetres.
 * Match the repository plan: PA2=TIM5_CH3/tilt, PA3=TIM5_CH4/pan,
 * PA15=KEY1, PC13=status LED, PC0=motor standby low.
 * PE0 drives the active-high MOS switch signal: low = laser off,
 * high = laser on. Servo PWM remains on PA2 and PA3 only.
 * Provisional A4 setup: paper landscape (297 x 210), upright, bottom level
 * with the gimbal mounting feet. Drawing gives tilt axis about 80 mm above
 * the feet, so paper centre (105 mm high) is 25 mm above the tilt axis.
 * Assume the pivot is on AB for a 500 mm pivot-to-paper normal distance.
 * Replace both geometry values after measuring the assembled car and paper.
 */
#define PAPER_DISTANCE_MM             500.0f
#define PAPER_CENTER_ABOVE_PIVOT_MM     25.0f
#define PAN_CENTER_US                 1500.0f
#define TILT_CENTER_US                1500.0f
#define PAN_SIGN                         1.0f
#define TILT_SIGN                        1.0f
#define PAN_US_PER_DEGREE              (2000.0f / 270.0f)
#define TILT_US_PER_DEGREE             (2000.0f / 180.0f)
#define SERVO_MIN_US                   1050.0f
#define SERVO_MAX_US                   1950.0f
#define DRAW_STEPS                     225U
#define DRAW_STEP_MS                    20U
#define CIRCLE_RETURN_FRAMES              8U /* 8 x 20 ms actual TIM5 frames */
#define SERVO_SETTLE_MS                700U
#define CENTER_DOT_MS                  300U
#define KEY_DEBOUNCE_MS                 30U
#define KEY_HOLD_MS                   1500U
#define PI_F                             3.14159265358979323846f

/* Mode 0: centre dot, then A/B/C/D from the competition specification. */
typedef enum { CENTER_DOT, TRIANGLE, SQUARE, CIRCLE, SINE_WAVE } Shape;
typedef enum { IDLE, SETTLING, DRAWING, RETURN_CHECK, DOT_ON } RunState;

static volatile uint32_t milliseconds;
static volatile uint8_t laser_enabled;
static Shape selected_shape = CENTER_DOT;
static RunState run_state = IDLE;
static uint32_t state_started_ms;
static uint16_t point_index;
static uint16_t circle_start_pan_us, circle_start_tilt_us;
static uint8_t circle_return_frames;
static uint8_t raw_key, stable_key, long_handled, abort_armed;
static uint32_t key_changed_ms, key_pressed_ms;

static void laser_off(void)
{
  laser_enabled = 0U;
  GPIOE->BSRR = (uint32_t)GPIO_PIN_0 << 16;
}
static void laser_on(void)
{
  GPIOE->BSRR = GPIO_PIN_0;
  laser_enabled = 1U;
}
static void led_set(uint8_t on)
{
  GPIOC->BSRR = on ? ((uint32_t)GPIO_PIN_13 << 16) : GPIO_PIN_13;
}

void SysTick_Handler(void)
{
  ++milliseconds;
}

static void stop_drawing(void)
{
  laser_off();
  run_state = IDLE;
  abort_armed = 0U;
}

static void fail_closed(void)
{
  laser_off();
  GPIOC->BSRR = (uint32_t)GPIO_PIN_0 << 16; /* motor standby off */
  while (1) { led_set(1U); }
}

void HardFault_Handler(void) { fail_closed(); }
void MemManage_Handler(void) { fail_closed(); }
void BusFault_Handler(void)  { fail_closed(); }
void UsageFault_Handler(void){ fail_closed(); }
void Default_Handler(void)   { fail_closed(); }

static void hardware_init(void)
{
  /* Run this standalone experiment from the reset HSI clock at 16 MHz.
   * TIM5 prescaler 15 => 1 MHz, ARR 19999 => 50 Hz servo PWM.
   */
  RCC->CR |= RCC_CR_HSION;
  while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { }
  RCC->CFGR &= ~(RCC_CFGR_SW | RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
  while ((RCC->CFGR & RCC_CFGR_SWS) != 0U) { }
  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOCEN |
                  RCC_AHB1ENR_GPIOEEN;
  (void)RCC->AHB1ENR;
  /* Establish off levels before switching PE0 and PC0 to outputs. */
  GPIOE->BSRR = (uint32_t)GPIO_PIN_0 << 16;
  GPIOC->BSRR = (uint32_t)GPIO_PIN_0 << 16;
  GPIOC->BSRR = GPIO_PIN_13;
  GPIOE->PUPDR = (GPIOE->PUPDR & ~3U) | 2U; /* PE0 pull-down */
  GPIOE->MODER = (GPIOE->MODER & ~3U) | 1U; /* PE0 output */
  GPIOE->OTYPER &= ~GPIO_PIN_0;          /* push-pull */
  GPIOC->MODER = (GPIOC->MODER & ~((3U << 0) | (3U << 26))) |
                 (1U << 0) | (1U << 26);
  GPIOC->OTYPER &= ~(GPIO_PIN_0 | GPIO_PIN_13);
  if (SysTick_Config(16000U) != 0U) fail_closed();

  /* On the current board KEY1 is PA15, active low. */
  GPIOA->MODER &= ~(3U << 30);
  GPIOA->PUPDR = (GPIOA->PUPDR & ~(3U << 30)) | (1U << 30);

  /* PA2, PA3 alternate function AF2 = TIM5 channels 3 and 4. */
  GPIOA->MODER = (GPIOA->MODER & ~((3U << 4) | (3U << 6))) |
                 (2U << 4) | (2U << 6);
  GPIOA->AFR[0] = (GPIOA->AFR[0] & ~((15U << 8) | (15U << 12))) |
                   (2U << 8) | (2U << 12);
  GPIOA->OTYPER &= ~(GPIO_PIN_2 | GPIO_PIN_3);

  RCC->APB1ENR |= RCC_APB1ENR_TIM5EN;
  TIM5->PSC = 15U;
  TIM5->ARR = 19999U;
  TIM5->CCR3 = 1500U;
  TIM5->CCR4 = 1500U;
  TIM5->CCMR2 = (6U << 4) | (1U << 3) | (6U << 12) | (1U << 11);
  TIM5->CCER = TIM_CCER_CC3E | TIM_CCER_CC4E;
  TIM5->CR1 = TIM_CR1_ARPE;
  TIM5->EGR = TIM_EGR_UG;
  TIM5->CR1 |= TIM_CR1_CEN;
  laser_off();
}

static void line_point(float s, float x0, float y0, float x1, float y1,
                       float *u, float *v)
{
  *u = x0 + s * (x1 - x0);
  *v = y0 + s * (y1 - y0);
}

static void shape_point(Shape shape, float t, float *u, float *v)
{
  float s;
  switch (shape) {
  case CENTER_DOT:
    *u = 0.0f; *v = 0.0f; break;
  case TRIANGLE: {
    const float h = 155.88457268f; /* 180 mm equilateral triangle */
    s = 3.0f * t;
    if (s < 1.0f)
      line_point(s, 0.0f, h/2.0f,
                 90.0f, -h/2.0f, u, v);
    else if (s < 2.0f)
      line_point(s-1.0f, 90.0f, -h/2.0f,
                 -90.0f, -h/2.0f, u, v);
    else
      line_point(s-2.0f, -90.0f, -h/2.0f,
                 0.0f, h/2.0f, u, v);
    break;
  }
  case SQUARE:
    s = 4.0f * t;
    if      (s < 1.0f) line_point(s, -90, 90, 90, 90, u, v);
    else if (s < 2.0f) line_point(s-1, 90, 90, 90, -90, u, v);
    else if (s < 3.0f) line_point(s-2, 90, -90, -90, -90, u, v);
    else               line_point(s-3, -90, -90, -90, 90, u, v);
    break;
  case CIRCLE:
    *u = 90.0f * sinf(2.0f * PI_F * t);
    *v = 90.0f * cosf(2.0f * PI_F * t);
    break;
  case SINE_WAVE:
    *u = -135.0f + 270.0f * t;
    *v = 80.0f * sinf(6.0f * PI_F * t);
    break;
  default:
    *u = *v = 0.0f;
  }
}

/* u positive: paper right; v positive: paper up. Returns 0 if a
 * calibration value would exceed the deliberately conservative PWM window.
 */
static uint8_t aim_at(float u, float v)
{
  const float p = atan2f(u, PAPER_DISTANCE_MM) * (180.0f / PI_F);
  const float t = atan2f(v + PAPER_CENTER_ABOVE_PIVOT_MM,
                         sqrtf(PAPER_DISTANCE_MM*PAPER_DISTANCE_MM + u*u))
                  * (180.0f / PI_F);
  const float pan = PAN_CENTER_US + PAN_SIGN * PAN_US_PER_DEGREE * p;
  const float tilt = TILT_CENTER_US + TILT_SIGN * TILT_US_PER_DEGREE * t;
  if (!isfinite(pan) || !isfinite(tilt) ||
      pan < SERVO_MIN_US || pan > SERVO_MAX_US ||
      tilt < SERVO_MIN_US || tilt > SERVO_MAX_US) return 0U;
  TIM5->CCR4 = (uint32_t)(pan + 0.5f);
  TIM5->CCR3 = (uint32_t)(tilt + 0.5f);
  return 1U;
}

static void start_drawing(uint32_t now)
{
  float u, v;
  shape_point(selected_shape, 0.0f, &u, &v);
  laser_off();
  if (!aim_at(u, v)) { stop_drawing(); return; }
  if (selected_shape == CIRCLE) {
    circle_start_pan_us = (uint16_t)TIM5->CCR4;
    circle_start_tilt_us = (uint16_t)TIM5->CCR3;
  }
  point_index = 0U;
  state_started_ms = now;
  run_state = SETTLING;
  abort_armed = 0U;
}

static void update_key(uint32_t now)
{
  const uint8_t pressed = (GPIOA->IDR & GPIO_PIN_15) == 0U;
  if (pressed != raw_key) { raw_key = pressed; key_changed_ms = now; }
  if (raw_key != stable_key && now-key_changed_ms >= KEY_DEBOUNCE_MS) {
    stable_key = raw_key;
    if (stable_key) {
      key_pressed_ms = now;
      long_handled = 0U;
      if (run_state != IDLE && abort_armed) {
        stop_drawing();
        long_handled = 1U; /* abort release must not select another shape */
      }
    } else {
      if (run_state == IDLE && !long_handled &&
          now-key_pressed_ms < KEY_HOLD_MS)
        selected_shape = (Shape)(((unsigned)selected_shape+1U) % 5U);
      if (run_state != IDLE) abort_armed = 1U;
    }
  }
  if (run_state == IDLE && stable_key && !long_handled &&
      now-key_pressed_ms >= KEY_HOLD_MS) {
    long_handled = 1U;
    start_drawing(now);
  }
}

static void update_drawing(uint32_t now)
{
  float u, v;
  if (run_state == IDLE) return;
  if (run_state == SETTLING && now-state_started_ms >= SERVO_SETTLE_MS) {
    laser_on();
    state_started_ms = now;
    run_state = selected_shape == CENTER_DOT ? DOT_ON : DRAWING;
  }
  if (run_state == DOT_ON && now-state_started_ms >= CENTER_DOT_MS)
    stop_drawing();
  if (run_state == RETURN_CHECK && (TIM5->SR & TIM_SR_UIF) != 0U) {
    TIM5->SR = ~TIM_SR_UIF;
    /* This checks the commanded PWM registers, not the servo's shaft. */
    if (TIM5->CCR4 != circle_start_pan_us ||
        TIM5->CCR3 != circle_start_tilt_us) fail_closed();
    if (++circle_return_frames >= CIRCLE_RETURN_FRAMES) stop_drawing();
  }
  if (run_state == DRAWING && now-state_started_ms >= DRAW_STEP_MS) {
    state_started_ms = now;
    ++point_index;
    if (point_index > DRAW_STEPS) { stop_drawing(); return; }
    if (selected_shape == CIRCLE && point_index == DRAW_STEPS) {
      /* Exact same command as the settled starting point. No overrun. */
      TIM5->CCR4 = circle_start_pan_us;
      TIM5->CCR3 = circle_start_tilt_us;
      TIM5->SR = ~TIM_SR_UIF;
      circle_return_frames = 0U;
      run_state = RETURN_CHECK;
    } else {
      shape_point(selected_shape, (float)point_index/(float)DRAW_STEPS, &u, &v);
      if (!aim_at(u, v)) { stop_drawing(); return; }
      if (point_index == DRAW_STEPS) stop_drawing();
    }
  }
}

int main(void)
{
  hardware_init();
  if (!aim_at(0.0f, 0.0f)) fail_closed();
  while (1) {
    const uint32_t now = milliseconds;
    update_key(now);
    update_drawing(now);
    if (run_state == IDLE) {
      const uint32_t phase = now % 4000U;
      const uint32_t flashes = (uint32_t)selected_shape + 1U;
      led_set((phase < flashes * 700U && phase % 700U < 400U) ? 1U : 0U);
    } else {
      led_set(laser_enabled);
    }
  }
}
